// Leaflet Kaart Initialiseren
document.addEventListener('DOMContentLoaded', function() {
    // Initialiseer de kaart
    // Bazel, België coördinaten
    const map = L.map('map').setView([50.8888, 4.5114], 15);
    
    // Voeg OpenStreetMap tiles toe
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors',
        maxZoom: 19,
        opacity: 0.8
    }).addTo(map);
    
    // Voeg marker toe voor de winkel
    const marker = L.marker([50.8888, 4.5114]).addTo(map);
    marker.bindPopup('<b>Vintage Bazel</b><br>Marktplein 42<br>4000 Bazel, België<br><strong>Tel:</strong> +32 (0)1 234 56 789').openPopup();
    
    // Voeg een cirkel toe rond de winkel
    L.circle([50.8888, 4.5114], {
        color: '#8b5a3c',
        fillColor: '#d4a574',
        fillOpacity: 0.2,
        radius: 500
    }).addTo(map);
});

// Contact Formulier Verwerking
document.addEventListener('DOMContentLoaded', function() {
    const contactForm = document.getElementById('contactForm');
    const formMessage = document.getElementById('formMessage');
    
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Haal formulier gegevens op
            const name = document.getElementById('name').value;
            const email = document.getElementById('email').value;
            const subject = document.getElementById('subject').value;
            const message = document.getElementById('message').value;
            
            // Eenvoudige validatie
            if (name.trim() === '' || email.trim() === '' || subject.trim() === '' || message.trim() === '') {
                showMessage('Vul alstublieft alle velden in!', 'error');
                return;
            }
            
            // Email validatie
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                showMessage('Voer alstublieft een geldig e-mailadres in!', 'error');
                return;
            }
            
            // Simuleer verzending (in real scenario zou je dit naar een server sturen)
            console.log('Formulier verzonden:', { name, email, subject, message });
            
            showMessage('Bedankt voor uw bericht! We nemen zo snel mogelijk contact met u op.', 'success');
            
            // Reset formulier
            contactForm.reset();
            
            // Verberg bericht na 5 seconden
            setTimeout(() => {
                formMessage.classList.remove('success', 'error');
            }, 5000);
        });
    }
});

// Helper functie voor formulier berichten
function showMessage(msg, type) {
    const formMessage = document.getElementById('formMessage');
    formMessage.textContent = msg;
    formMessage.classList.remove('success', 'error');
    formMessage.classList.add(type);
}
